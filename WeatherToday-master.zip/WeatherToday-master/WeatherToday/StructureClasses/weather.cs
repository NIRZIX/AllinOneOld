﻿namespace WeatherToday.CustomClasses
{
    public class weather
    {
        public string main;
        public string description;
        public string icon;
    }
}
