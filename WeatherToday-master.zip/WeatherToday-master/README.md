# WeatherToday
УП_2022_YearEnd

Completed

P. S. Последний commit не учтен в УП! Реализован Timeout для "совести", даже после подготовки ПП. Работа без VPN не гарантируется!
