﻿namespace PW5M_Calculator;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
