# SQLWork-PW8MPC
## Презентативная работа на Xamarin и MAUI по SQL соединению.  
>**Работа выполнена студентом ***[Sergey Lopatkin](https://github.com/HaproBishop)*****

Основное содержание данного архива:
* Программа из практической работы на 3 курсе
* Программа для демонстрации работы в Xamarin
* Программу для демонстрации работы в MAUI
* Скрипт для заполнения БД

Таблица совместимости SQL Server 2019 с платформой разработки и ОС.
OS     |   MAUI   |    Xamarin
:------|:--------:|:-----------:
Windows | + | +
Android | - | +

[![Internet Pircture](https://static.vecteezy.com/system/resources/previews/000/275/138/original/vector-winter-landscape-illustration.jpg)](https://github.com/HaproBishop)
